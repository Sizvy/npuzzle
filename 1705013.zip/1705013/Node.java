package algo;

public class Node {
    int[] state;
    int ownID;
    Node parent;
    int depth;
    int pathcost;

    public Node(int[] state, int ownID, Node parent, int depth, int pathcost) {
        this.state = state;
        this.ownID = ownID;
        this.parent = parent;
        this.depth = depth;
        this.pathcost = pathcost;
    }

    public Node() {
    }

    public void setPathcost(int pathcost) {
        this.pathcost = pathcost;
    }

    public void setState(int[] state) {
        this.state = state;
    }

    public void setOwnID(int ownID) {
        this.ownID = ownID;
    }

    public void setParent(Node parent) {
        this.parent = parent;
    }

    public void setDepth(int depth) {
        this.depth = depth;
    }

    public int[] getState() {
        return state;
    }

    public int getOwnID() {
        return ownID;
    }

    public Node getParent() {
        return parent;
    }

    public int getDepth() {
        return depth;
    }

    public int getPathcost() {
        return pathcost;
    }
}
