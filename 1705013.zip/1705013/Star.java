package algo;

import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Scanner;

public class Star {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Number of grid size(k): ");
        int k = scanner.nextInt();
        System.out.println("Enter the initial Board position(Enter value of k^2 for the blank spot): ");
        int[] initial_board = new int[k*k];
        for(int i=0;i<k*k;i++){
            initial_board[i] = scanner.nextInt();
        }
        System.out.println("Given Initial Board: ");
        printBoard(initial_board,k);
        if(isSolvable(initial_board,k))
            System.out.println("Solvable");
        else
            System.out.println("Unsolvable");
        //System.out.println(InversionCalc(k,initial_board));
        //System.out.println(LinearConflict(k,initial_board));
        if(isSolvable(initial_board,k)){
            System.out.println("Manhatton");
            System.out.println("Manhatton path cost: "+getGoal(initial_board,k,2));
            System.out.println("Linear Conflict Heuristic: ");
            System.out.println("Linear Conflict Heuristic path cost: "+getGoal(initial_board,k,3));
            System.out.println("Hamming: ");
            System.out.println("Hamming path cost: "+getGoal(initial_board,k,1));
        }
    }
    public static int InversionCalc(int k,int[] givenBoard){
        int inversion=0;
        for(int i=0;i<k*k;i++){
            int val = givenBoard[i];
            if(val>(k*k-1))
                continue;
            for(int j=i+1;j<k*k;j++){
                if(val>givenBoard[j]){
                    inversion++;
                }
            }
        }
        return inversion;
    }
    public static int HammingDistance(int k, int[] givenBoard){
        int h=0;
        int[] goal = new int[k*k];
        for(int i=0;i<k*k;i++){
            goal[i] = i+1;
        }
        for(int i=0;i<k*k;i++){
            if(goal[i]==9){

            }
            else if(goal[i]!=givenBoard[i]){
                h++;
            }
        }
        return  h;
    }
    public static int ManhattanDistance(int k, int[] givenBoard){
        int h=0,row,col;
        for(int i=0;i<k*k;i++){
            for(int j=0;j<k*k;j++){
                if((i+1)==givenBoard[j] && (i+1)<k*k){
                    //System.out.println(rowCalc(j,k)+" "+rowCalc(i,k)+" "+givenBoard[j]);
                    //System.out.println(colCalc(j,k)+" "+colCalc(i,k)+" "+givenBoard[j]);
                    row = Math.abs(rowCalc(j,k)-rowCalc(i,k));
                    col = Math.abs(colCalc(j,k)-colCalc(i,k));
                    h+=row+col;
                    break;
                }
            }
        }
        return h;
    }
    public static int LinearConflict(int k, int[] givenBoard){
        int conflict=0;
        boolean[] isCorrectRow = new boolean[k*k];
        for(int i=0;i<k*k;i++){
            if(givenBoard[i]==9)
                isCorrectRow[i]=false;
            else{
                isCorrectRow[i]=(Math.ceil(givenBoard[i]*1.0/k)==Math.ceil((i+1)*1.0/k));
            }
        }
        for(int i=0;i<k*k;i++){
            if(isCorrectRow[i]){
                for(int j=i+1;j<k*k;j++){
                    if(isCorrectRow[j] && rowCalc(i,k)==rowCalc(j,k)){
                        if(givenBoard[i]>givenBoard[j])
                            conflict++;
                    }
                }
            }
        }
        return conflict;
    }
    public static int LinearConflictHeuristic(int k, int[] givenBoard){
        return ManhattanDistance(k,givenBoard)+2*LinearConflict(k,givenBoard);
    }
    public static boolean isAdjacent(int index, int k, int index_of_blank){
        if(rowCalc(index,k)==rowCalc(index_of_blank,k) && Math.abs(colCalc(index,k)-colCalc(index_of_blank,k))==1){
            return true;
        }
        else if(colCalc(index,k)==colCalc(index_of_blank,k) && Math.abs(rowCalc(index,k)-rowCalc(index_of_blank,k))==1){
            return true;
        }
        else
            return false;
    }
    public static int rowCalc(int idx, int k){
        return Math.floorDiv(idx,k);
    }
    public static int colCalc(int idx, int k){
        return idx%k;
    }
    public static ArrayList<Node> shuffle(Node givenBoard, int k, int choice){
        int index_of_blank=0;
        ArrayList<Node> expanded = new ArrayList<>(100);
        for(int i=0;i<k*k;i++){
            if(givenBoard.getState()[i]>=k*k){
                index_of_blank = i;
                break;
            }
        }
        for(int i=0;i<k*k;i++){
            int[] carrier = new int[k*k];
            for(int j=0;j<k*k;j++){
                carrier[j] = givenBoard.getState()[j];
            }
            if(isAdjacent(i,k,index_of_blank)){
                int temp = carrier[index_of_blank];
                carrier[index_of_blank] = carrier[i];
                carrier[i]=temp;
                if(choice==1)
                    expanded.add(new Node(carrier,HammingDistance(k,carrier),givenBoard,givenBoard.getDepth()+1,givenBoard.getDepth()+1+HammingDistance(k,carrier)));
                else if(choice==2){
                    expanded.add(new Node(carrier,ManhattanDistance(k,carrier),givenBoard,givenBoard.getDepth()+1,givenBoard.getDepth()+1+ManhattanDistance(k,carrier)));
                }
                else{
                    expanded.add(new Node(carrier,LinearConflictHeuristic(k,carrier),givenBoard,givenBoard.getDepth()+1,givenBoard.getDepth()+1+LinearConflictHeuristic(k,carrier)));
                }
            }
        }
        return expanded;
    }
    public static void printBoard(int[] initial_board,int k){
        for(int i=0;i<k*k;i++){
            if((i+1)%k==0){
                if(initial_board[i]>(k*k-1)){
                    System.out.println("*"+"\n");
                }
                else
                    System.out.println(initial_board[i]+"\n");
            }
            else{
                if(initial_board[i]>(k*k-1)){
                    System.out.print("*"+" ");
                }
                else
                    System.out.print(initial_board[i]+" ");}

        }
    }
    public static boolean compareBoard(int[] b1, int[] b2, int k){
        int i;
        for(i=0;i<k*k;i++){
            if(b1[i]!=b2[i]){
                break;
            }
        }
        if(i==k*k)
            return true;
        else
            return false;
    }
    public static boolean isSolvable(int[] givenBoard, int k){
        int No_of_inversions = InversionCalc(k,givenBoard);
        int index_of_blank=0;
        for(int i=0;i<k*k;i++){
            if(givenBoard[i]>=k*k){
                index_of_blank = i;
                break;
            }
        }
        //System.out.println(index_of_blank);
        int row_of_blank = (int) Math.ceil((k*k-index_of_blank)*1.0/k);
        //System.out.println(row_of_blank);
        if(k%2!=0 && No_of_inversions%2==0){
            return true;
        }
        else if(k%2==0 && No_of_inversions%2!= 0 && row_of_blank%2==0){
            return true;
        }
        else if(k%2==0 && No_of_inversions%2==0 && row_of_blank%2!=0){
            return true;
        }
        else{
            return false;
        }
    }
    public static int getGoal(int[] givenBoard, int k, int choice){
        int[] goal = new int[k*k];
        for(int i=0;i<k*k;i++){
            goal[i] = i+1;
        }
        PriorityQueue<Node> open = new PriorityQueue<Node>(1000,new NodeComparator());
        ArrayList<Node> closed = new ArrayList<>();
        ArrayList<Node> shuffled;
        Node newNode = new Node();
        int ex=0;
        int optimal_cost=0;
        if(choice==1)
            newNode = new Node(givenBoard,HammingDistance(k,givenBoard),null,0,HammingDistance(k,givenBoard));
        else if(choice==2)
            newNode = new Node(givenBoard,ManhattanDistance(k,givenBoard),null,0,ManhattanDistance(k,givenBoard));
        else
            newNode = new Node(givenBoard,LinearConflictHeuristic(k,givenBoard),null,0,LinearConflictHeuristic(k,givenBoard));
        open.add(newNode);
        while (open.size()!=0){
            Node node = open.remove();
            closed.add(node);
            if(compareBoard(node.getState(),goal,k)){
                System.out.println("Goal state reached");
                //int ex = open.size()+closed.size();
                System.out.println("Explored nodes: "+ex);
                System.out.println("Expanded nodes: "+(closed.size()-1));
                optimal_cost = node.getPathcost();
                ArrayList<Node> Print = new ArrayList<>(1000);
                while (node.getParent()!=null){
                    Print.add(node);
                    node = node.getParent();
                }
                Print.add(newNode);
                for(int l=Print.size()-1;l>=0;l--){
                    System.out.println("Step-"+(Print.size()-l));
                    printBoard(Print.get(l).getState(),k);
                }
                return optimal_cost;
            }
            shuffled = shuffle(node,k,choice);
            for(int j=0;j<shuffled.size();j++){
                int l;
                for(l=0;l<closed.size();l++){
                    if(compareBoard(shuffled.get(j).getState(),closed.get(l).getState(),k)){
                        break;
                    }
                }
                if(l==closed.size()){
                    open.add(shuffled.get(j));
                    ex++;
                }
            }
        }
        return optimal_cost;
    }
}
