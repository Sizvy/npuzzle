package algo;

import java.util.Comparator;

public class NodeComparator implements Comparator<Node> {

    @Override
    public int compare(Node o1, Node o2) {
        if(o1.getPathcost()>o2.getPathcost())
            return 1;
        else if(o1.getPathcost()<o2.getPathcost())
            return -1;
        else{
            if(o1.getOwnID()>o2.getOwnID())
                return 1;
            else if(o1.getOwnID()<o2.getOwnID())
                return -1;
            else return 0;
        }
    }
}
